// JAVA SCRIPT FOR SCROLLING ***about_part*** 
function myFunction(){
    var elmnt =
    document.getElementById("about_part");
    elmnt.scrollIntoView();
}


// JQUERY ELEMENT******
$(document).ready(function(){

          //CANVES MANUE
          $(".menue_br").on('click', function (){
            $(".offcanvas-menu-wrapper").addClass("active");
            $(".offcanvas-menu-overlay").addClass("active");
        });
    
        $(".offcanvas-menu-overlay").on('click', function () {
            $(".offcanvas-menu-wrapper").removeClass("active");
            $(".offcanvas-menu-overlay").removeClass("active");
        });

          // CUSTOMS CURSOR
    $('.dased_anim').hover(function(){
    $('.cursor:nth-child(2)').hide();
        },function(){
          $('.cursor:nth-child(2)').show();
    });

    /*------------------
        Achieve Counter
    --------------------*/
    $('.achieve-counter').each(function () {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
        }, {
            duration: 4000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });

    
})


// CUSTOMS CURSOR
$(document).mousemove(function(e){
    $('.cursor').eq(0).css({left: e.clientX, top: e.clientY});

    setTimeout(function(){
    $('.cursor').eq(1).css({left: e.clientX, top: e.clientY});
    },50);
});